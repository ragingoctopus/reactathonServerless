# reactathonServerless
the backend for the Reactathon application built with AWS and serverless
